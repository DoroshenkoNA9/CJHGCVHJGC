from server.sql_base.models import TypeOfService
from server.resolves.company import dbmanager


def get(type_id: int) -> TypeOfService | None:
    res = dbmanager.execute_query(
        query='select * from type_of_service where id=(?)',
        args=(type_id,))

    return None if not res else TypeOfService(
        id=res[0],
        title=res[1]
    )


def get_all() -> list[TypeOfService] | dict:
    l = dbmanager.execute_query(
        query="select * from type_of_service",
        fetchone=False)

    res = []

    if l:
        for c in l:
            res.append(TypeOfService(
                id=c[0],
                title=c[1]
            ))

    return res


def delete(type_id: int) -> None:
    return dbmanager.execute_query(
        query='delete from type_of_service where id=(?)',
        args=(type_id,))


def create(new_type: TypeOfService) -> int | dict:
    res = dbmanager.execute_query(
        query="insert into type_of_service (title) values(?) returning id",
        args=(new_type.title, ))

    if type(res) != dict:
        res = get(res[0])

    return res


def update(type_id: int, new_data: TypeOfService) -> None:
    return dbmanager.execute_query(
        query="update type_of_service set (title) = (?) where id=(?)",
        args=(new_data.title, type_id))

