from server.sql_base.models import Client, Auth
from server.resolves.company import dbmanager


def get(client_id: int) -> Client | None:
    res = dbmanager.execute_query(
        query='select * from Client where id=(?)',
        args=(client_id,))

    return None if not res else Client(
        id=res[0],
        name=res[1],
        surname=res[2],
        telephone=res[3],
        email=res[4],
        note=res[5],
        password=res[6]
    )


def get_all() -> list[Client] | dict:
    l = dbmanager.execute_query(
        query="select * from Client",
        fetchone=False)

    res = []

    if l:
        for c in l:
            res.append(Client(
                id=c[0],
                name=c[1],
                surname=c[2],
                telephone=c[3],
                email=c[4],
                note=c[5],
                password=c[6]
            ))

    return res


def delete(client_id: int) -> None:
    return dbmanager.execute_query(
        query='delete from Client where id=(?)',
        args=(client_id,))


def create(new_client: Client) -> int | dict:
    res = dbmanager.execute_query(
        query="insert into Client (name, surname, telephone, email, note, password) values(?,?,?,?,?,?) returning id",
        args=(new_client.name, new_client.surname, new_client.telephone, new_client.email, new_client.note, new_client.password))

    if type(res) != dict:
        res = get(res[0])

    return res


def update(client_id: int, new_data: Client) -> None:
    return dbmanager.execute_query(
        query="update Client set (name, surname, telephone, email, note, password) = (?,?,?,?,?,?) where id=(?)",
        args=(new_data.name, new_data.surname, new_data.telephone, new_data.email, new_data.note, new_data.password, client_id))


def login(client: Auth):
    res = dbmanager.execute_query(
        query='select id from Client where telephone=(?) and password=(?) ',
        args=(client.login, client.password)
    )

    return res
