from server.sql_base.models import Record
from server.resolves.company import dbmanager


def get(_id: int) -> Record | None:
    res = dbmanager.execute_query(
        query='select * from Record where id=(?)',
        args=(_id,))

    return None if not res else Record(
        id=res[0],
        company_id=res[1],
        client_id=res[2],
        staff_id=res[3],
        service_id=res[4],
        maeterial_id=res[5],
        date_of_work=res[6],
        start_time=res[7],
        end_time=res[8],
        price=res[9],
        note=res[10]
    )


def get_all() -> list[Record] | dict:
    l = dbmanager.execute_query(
        query="select * from Record",
        fetchone=False)

    res = []

    if l:
        for res in l:
            res.append(Record(
                id=res[0],
                company_id=res[1],
                client_id=res[2],
                staff_id=res[3],
                service_id=res[4],
                maeterial_id=res[5],
                date_of_work=res[6],
                start_time=res[7],
                end_time=res[8],
                price=res[9],
                note=res[10]
            ))

    return res


def delete(_id: int) -> None:
    return dbmanager.execute_query(
        query='delete from Record where id=(?)',
        args=(_id,))


def create(new: Record) -> int | dict:
    res = dbmanager.execute_query(
        query="insert into Record (company_id, client_id, staff_id, service_id, material_id, date_of_work, start_time, end_time, price, note) values(?,?,?,?,?,?,?,?,?,?) returning id",
        args=(new.company_id, new.client_id, new.staff_id, new.service_id, new.material_id, new.date_of_work, new.start_time, new.end_time, new.price, new.note))

    if type(res) != dict:
        res = get(res[0])

    return res


def update(type_id: int, new_data: Record) -> None:
    return dbmanager.execute_query(
        query="update Record set (company_id, client_id, staff_id, service_id, material_id, date_of_work, start_time, end_time, price, note) = (?,?,?,?,?,?,?,?,?,?) where id=(?)",
        args=(new_data.company_id, new_data.client_id, new_data.staff_id, new_data.service_id, new_data.material_id, new_data.date_of_work, new_data.start_time, new_data.end_time, new_data.price, new_data.note, type_id))

