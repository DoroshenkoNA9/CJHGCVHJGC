from server.sql_base.models import Company
import settings
from server.sql_base.dbmanager import DbManager

dbmanager = DbManager(db_path=settings.DATABASE_PATH)


def get(company_id: int) -> Company | None:
    res = dbmanager.execute_query(
        query='select * from Company where id=(?)',
        args=(company_id,))

    return None if not res else Company(
        id=res[0],
        name_company=res[1],
        address=res[2],
        telephone=res[3],
        email=res[4],
        note=res[5]
    )


def get_all() -> list[Company] | dict:
    l = dbmanager.execute_query(
        query="select * from Company",
        fetchone=False)

    res = []

    if l:
        for i in l:
            res.append(Company(
                id=i[0],
                name_company=i[1],
                address=i[2],
                telephone=i[3],
                email=i[4],
                note=i[5]
    ))

    return res


def delete(company_id: int) -> None:
    return dbmanager.execute_query(
        query='delete from Company where id=(?)',
        args=(company_id,))


def create(new_company: Company) -> int | dict:
    res = dbmanager.execute_query(
        query="insert into Company(name_company, address, telephone, email, note) values(?, ?, ?, ?, ?) returning id",
        args=(new_company.name_company, new_company.address, new_company.telephone, new_company.email, new_company.note,))

    if type(res) != dict:
        res = get(res[0])

    return res


def update(company_id: int, new_company: Company) -> None:
    return dbmanager.execute_query(
        query="update Company set (name_company, address, telephone, email, note) = (?, ?, ?, ?, ?) where id=(?)",
        args=(new_company.name_company, new_company.address, new_company.telephone, new_company.email, new_company.note, company_id, ))
