from server.sql_base.models import Staff
from server.resolves.company import dbmanager


def get(_id: int) -> Staff | None:
    res = dbmanager.execute_query(
        query='select * from Staff where id=(?)',
        args=(_id,))

    return None if not res else Staff(
        id=res[0],
        post_id=res[1],
        department_id=res[2],
        name=res[3],
        suname=res[4],
        passport_data=res[5],
        address=res[6],
        telephone=res[7],
        email=res[8],
        note=res[9]
    )


def get_all() -> list[Staff] | dict:
    l = dbmanager.execute_query(
        query="select * from Staff",
        fetchone=False)

    res = []

    if l:
        for res in l:
            res.append(Staff(
                id=res[0],
                post_id=res[1],
                department_id=res[2],
                name=res[3],
                suname=res[4],
                passport_data=res[5],
                address=res[6],
                telephone=res[7],
                email=res[8],
                note=res[9]
            ))

    return res


def delete(_id: int) -> None:
    return dbmanager.execute_query(
        query='delete from Staff where id=(?)',
        args=(_id,))


def create(new: Staff) -> int | dict:
    res = dbmanager.execute_query(
        query="insert into Staff (post_id, department_id, name, surname, passport_data, address, telephone, email, note) values(?,?,?,?,?,?,?,?,?) returning id",
        args=(new.post_id, new.department_id, new.name, new.surname, new.passport_data, new.address, new.telephone, new.email, new.note))

    if type(res) != dict:
        res = get(res[0])

    return res


def update(type_id: int, new_data: Staff) -> None:
    return dbmanager.execute_query(
        query="update Material set (post_id, department_id, name, surname, passport_data, address, telephone, email, note) = (?,?,?,?,?,?,?,?,?) where id=(?)",
        args=(new_data.post_id, new_data.department_id, new_data.name, new_data.surname, new_data.passport_data, new_data.address, new_data.telephone, new_data.email, new_data.note, type_id))

