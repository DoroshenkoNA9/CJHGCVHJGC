from server.sql_base.models import Post
from server.resolves.company import dbmanager


def get(_id: int) -> Post | None:
    res = dbmanager.execute_query(
        query='select * from Post where id=(?)',
        args=(_id,))

    return None if not res else Post(
        id=res[0],
        name_post=res[1]
    )


def get_all() -> list[Post] | dict:
    l = dbmanager.execute_query(
        query="select * from Post",
        fetchone=False)

    res = []

    if l:
        for res in l:
            res.append(Post(
                id=res[0],
                name_post=res[1]
            ))

    return res


def delete(_id: int) -> None:
    return dbmanager.execute_query(
        query='delete from Post where id=(?)',
        args=(_id,))


def create(new: Post) -> int | dict:
    res = dbmanager.execute_query(
        query="insert into Post (name_post) values(?) returning id",
        args=(new.name_post, ))

    if type(res) != dict:
        res = get(res[0])

    return res


def update(type_id: int, new_data: Post) -> None:
    return dbmanager.execute_query(
        query="update Post set (name_post) = (?) where id=(?)",
        args=(new_data.name_post, type_id))

