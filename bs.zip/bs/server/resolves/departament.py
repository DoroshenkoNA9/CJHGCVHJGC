from server.sql_base.models import Departament
from server.resolves.company import dbmanager


def get(_id: int) -> Departament | None:
    res = dbmanager.execute_query(
        query='select * from Departament where id=(?)',
        args=(_id,))

    return None if not res else Departament(
        id=res[0],
        name_post=res[1]
    )


def get_all() -> list[Departament] | dict:
    l = dbmanager.execute_query(
        query="select * from Departament",
        fetchone=False)

    res = []

    if l:
        for res in l:
            res.append(Departament(
                id=res[0],
                name_post=res[1]
            ))

    return res


def delete(_id: int) -> None:
    return dbmanager.execute_query(
        query='delete from Departament where id=(?)',
        args=(_id,))


def create(new: Departament) -> int | dict:
    res = dbmanager.execute_query(
        query="insert into Departament (name_departament) values(?) returning id",
        args=(new.name_departament, ))

    if type(res) != dict:
        res = get(res[0])

    return res


def update(type_id: int, new_data: Departament) -> None:
    return dbmanager.execute_query(
        query="update Departament set (name_departament) = (?) where id=(?)",
        args=(new_data.name_departament, type_id))

