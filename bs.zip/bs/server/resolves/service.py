from server.sql_base.models import Service
from server.resolves.company import dbmanager


def get(_id: int) -> Service | None:
    res = dbmanager.execute_query(
        query='select * from Service where id=(?)',
        args=(_id,))

    return None if not res else Service(
        id=res[0],
        title=res[1],
        type_id=res[2],
        description=res[3]
    )


def get_all() -> list[Service] | dict:
    l = dbmanager.execute_query(
        query="select * from Service",
        fetchone=False)

    res = []

    if l:
        for res in l:
            res.append(Service(
                id=res[0],
                title=res[1],
                type_id=res[2],
                description=res[3]
            ))

    return res


def delete(_id: int) -> None:
    return dbmanager.execute_query(
        query='delete from Service where id=(?)',
        args=(_id,))


def create(new: Service) -> int | dict:
    res = dbmanager.execute_query(
        query="insert into Service (title, type_id, description) values(?, ?, ?) returning id",
        args=(new.title, new.type_id, new.description))

    if type(res) != dict:
        res = get(res[0])

    return res


def update(type_id: int, new_data: Service) -> None:
    return dbmanager.execute_query(
        query="update Service set (title, type_id, description) = (?, ?, ?) where id=(?)",
        args=(new_data.title, new_data.type_id, new_data.description, type_id))

