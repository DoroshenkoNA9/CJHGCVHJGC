import fastapi
from server.sql_base.models import Staff
from server.resolves import staff


router = fastapi.APIRouter(prefix='/staff', tags=['Staff'])


@router.get('/get/{_id}', response_model=Staff | None)
def get(_id: int) -> Staff | None:
    return staff.get(_id)


@router.get('/get_all', response_model=list[Staff])
def get_all() -> list[Staff]:
    return staff.get_all()


@router.delete('/delete/{_id}', response_model=None)
def delete(_id: int) -> None:
    return staff.delete(_id)


@router.post('/create/', response_model=Staff | dict)
def create(new: Staff) -> Staff | dict:
    return staff.create(new)


@router.put("/update/{_id}", response_model=None)
def update(_id: int, new_data: Staff) -> None:
    return staff.update(_id, new_data)

