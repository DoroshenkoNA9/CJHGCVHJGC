import fastapi
from server.sql_base.models import Material
from server.resolves import material


router = fastapi.APIRouter(prefix='/material', tags=['Material'])


@router.get('/get/{_id}', response_model=Material | None)
def get(_id: int) -> Material | None:
    return material.get(_id)


@router.get('/get_all', response_model=list[Material])
def get_all() -> list[Material]:
    return material.get_all()


@router.delete('/delete/{_id}', response_model=None)
def delete(_id: int) -> None:
    return material.delete(_id)


@router.post('/create/', response_model=Material | dict)
def create(new: Material) -> Material | dict:
    return material.create(new)


@router.put("/update/{_id}", response_model=None)
def update(_id: int, new_data: Material) -> None:
    return material.update(_id, new_data)

