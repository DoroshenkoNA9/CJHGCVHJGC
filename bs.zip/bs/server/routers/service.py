import fastapi
from server.sql_base.models import Service
from server.resolves import service

router = fastapi.APIRouter(prefix='/service', tags=['Service'])


@router.get('/get/{_id}', response_model=Service | None)
def get(_id: int) -> Service | None:
    return service.get(_id)


@router.get('/get_all', response_model=list[Service])
def get_all() -> list[Service]:
    return service.get_all()


@router.delete('/delete/{_id}', response_model=None)
def delete(_id: int) -> None:
    return service.delete(_id)


@router.post('/create/', response_model=Service | dict)
def create(new: Service) -> Service | dict:
    return service.create(new)


@router.put("/update/{_id}", response_model=None)
def update(_id: int, new_data: Service) -> None:
    return service.update(_id, new_data)

