import fastapi
from server.sql_base.models import Post
from server.resolves import post


router = fastapi.APIRouter(prefix='/post', tags=['Post'])


@router.get('/get/{_id}', response_model=Post | None)
def get(_id: int) -> Post | None:
    return post.get(_id)


@router.get('/get_all', response_model=list[Post])
def get_all() -> list[Post]:
    return post.get_all()


@router.delete('/delete/{_id}', response_model=None)
def delete(_id: int) -> None:
    return post.delete(_id)


@router.post('/create/', response_model=Post | dict)
def create(new: Post) -> Post | dict:
    return post.create(new)


@router.put("/update/{_id}", response_model=None)
def update(_id: int, new_data: Post) -> None:
    return post.update(_id, new_data)

