import fastapi
from server.sql_base.models import TypeOfService
from server.resolves import type_of_service

router = fastapi.APIRouter(prefix='/type_of_service', tags=['Type of service'])


@router.get('/get/{type_id}', response_model=TypeOfService | None)
def get(type_id: int) -> TypeOfService | None:
    return type_of_service.get(type_id)


@router.get('/get_all', response_model=list[TypeOfService])
def get_all() -> list[TypeOfService]:
    return type_of_service.get_all()


@router.delete('/delete/{type_id}', response_model=None)
def delete(type_id: int) -> None:
    return type_of_service.delete(type_id)


@router.post('/create/', response_model=TypeOfService | dict)
def create(new_type: TypeOfService) -> TypeOfService| dict:
    return type_of_service.create(new_type)


@router.put("/update/{type_id}", response_model=None)
def update(type_id: int, new_data: TypeOfService) -> None:
    return type_of_service.update(type_id, new_data)

