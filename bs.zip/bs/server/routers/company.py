import fastapi
from server.resolves import company
from server.sql_base.models import Company

router = fastapi.APIRouter(prefix='/company', tags=['Company'])


@router.get('/get/{company_id}', response_model=Company | None)
def get(company_id: int):
    return company.get(company_id)


@router.get('/get_all', response_model=list[Company] | dict)
def get_all():
    return company.get_all()


@router.delete('/delete/{company_id}', response_model=None)
def remove(company_id: int):
    return company.delete(company_id)


@router.post('/create/', response_model=Company | dict)
def create(new_company: Company):
    return company.create(new_company)


@router.put("/update/{company_id}", response_model=None)
def update(company_id: int, new_data: Company):
    return company.update(company_id=company_id, new_company=new_data)
