import fastapi
from server.sql_base.models import Departament
from server.resolves import departament


router = fastapi.APIRouter(prefix='/departament', tags=['Departament'])


@router.get('/get/{_id}', response_model=Departament | None)
def get(_id: int) -> Departament | None:
    return departament.get(_id)


@router.get('/get_all', response_model=list[Departament])
def get_all() -> list[Departament]:
    return departament.get_all()


@router.delete('/delete/{_id}', response_model=None)
def delete(_id: int) -> None:
    return departament.delete(_id)


@router.post('/create/', response_model=Departament | dict)
def create(new: Departament) -> Departament | dict:
    return departament.create(new)


@router.put("/update/{_id}", response_model=None)
def update(_id: int, new_data: Departament) -> None:
    return departament.update(_id, new_data)

