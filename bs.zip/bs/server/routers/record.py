import fastapi
from server.sql_base.models import Record
from server.resolves import record


router = fastapi.APIRouter(prefix='/record', tags=['Record'])


@router.get('/get/{_id}', response_model=Record | None)
def get(_id: int) -> Record | None:
    return record.get(_id)


@router.get('/get_all', response_model=list[Record])
def get_all() -> list[Record]:
    return record.get_all()


@router.delete('/delete/{_id}', response_model=None)
def delete(_id: int) -> None:
    return record.delete(_id)


@router.post('/create/', response_model=Record | dict)
def create(new: Record) -> Record | dict:
    return record.create(new)


@router.put("/update/{_id}", response_model=None)
def update(_id: int, new_data: Record) -> None:
    return record.update(_id, new_data)

