import fastapi
from server.resolves import client
from server.sql_base.models import Client, Auth

router = fastapi.APIRouter(prefix='/client', tags=['Client'])


@router.get('/get/{client_id}', response_model=Client | None)
def get(client_id: int) -> Client | None:
    return client.get(client_id)


@router.get('/get_all', response_model=list[Client] | dict)
def get_all() -> list[Client] | dict:
    return client.get_all()


@router.delete('/delete/{client_id}', response_model=None)
def remove(client_id: int) -> None:
    return client.delete(client_id)


@router.post('/create/', response_model=Client | dict)
def create(new_client: Client) -> Client | dict:
    return client.create(new_client)


@router.put("/update/{client_id}", response_model=None)
def update(client_id: int, new_data: Client):
    return client.update(client_id=client_id, new_data=new_data)


@router.post('/login')
def reader_login(c: Auth):
    return client.login(c)
