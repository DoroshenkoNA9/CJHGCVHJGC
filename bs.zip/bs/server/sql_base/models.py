from pydantic import BaseModel
from typing import Optional


class BaseModelModify(BaseModel):
    id: Optional[int]


class Company(BaseModelModify):
    name_company: str
    address: str
    telephone: str
    email: str
    note: str


class Client(BaseModelModify):
    name: str
    surname: str
    telephone: str
    email: str
    note: str
    password: str


class TypeOfService(BaseModelModify):
    title: str


class Service(BaseModelModify):
    title: str
    type_id: int
    description: str


class Post(BaseModelModify):
    name_post: str


class Departament(BaseModelModify):
    name_departament: str


class Material(BaseModelModify):
    name_material: str


class Staff(BaseModelModify):
    post_id: int
    department_id: int
    name: str
    surname: str
    passport_data: str
    address: str
    telephone: str
    email: str
    note: str


class Record(BaseModelModify):
    company_id: int
    client_id: int
    staff_id: int
    service_id: int
    material_id: int
    date_of_work: str
    start_time: str
    end_time: str
    price: int
    note: int


class Auth(BaseModel):
    login: str
    password: str

