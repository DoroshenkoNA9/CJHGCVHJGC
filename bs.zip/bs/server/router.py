from server.routers import (company, client, type_of_service,
                            service, post, departament,
                            material, staff, record)

routers = (
    company.router,
    client.router,
    type_of_service.router,
    service.router,
    post.router,
    departament.router,
    material.router,
    staff.router,
    record.router
)
